package com.hbh.canndy.util;

public interface CandyUtil {
    public String changeStr(String str);
}
